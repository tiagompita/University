package aula08.Ex2;

public interface Vegetariano {
    public static boolean Vegetariano = true;
}
