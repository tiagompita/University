package aula08.Ex1;

public interface KmPercorridosInterface {
    void trajeto(int quilometros);
    int ultimoTrajeto();
    int distanciaTotal();
    
}
  
