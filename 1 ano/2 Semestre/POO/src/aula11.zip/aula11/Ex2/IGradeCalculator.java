package aula11.Ex2;
import java.util.ArrayList;

public interface IGradeCalculator {

    double calculate(ArrayList<Double> grades);
}
