
public interface IBookCostCalculator {
   
    // days is the number of days of book loan
    public double calculateCost(int days);

}
