O output do programa pode aparecer deformado, pois depende do tamanho ecra de cada computador. O programa foi desenvolvido num ecra 24 polegadas

Bibliotecas presentes:
pip install requests
pip install colorama
pip install termcolor
pip install prettytable
pip install pytz
pip install datetime
pip install pywin32